package seleniumwebdriverconcepts.seleniumassignment;

public enum CaseFormat {
    LOWER,UPPER,RANDOM
}
